package com.anu.flightservice;

public class flightpojo {
	

}
