package com.anu.test;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args)
	{
		Stream<Integer> stream=Stream.iterate(0,i->i+2);
		List<Integer> list = stream.limit(20).collect(Collectors.toList());
		list.forEach(System.out::println);
	}

}
				
				
				
				
				
	
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				

