package com.parking;

public class CustomerDetails {

	private String car_owner;
	private String phone_no;
	private String time;
	int floor, section, compartment;
	public CustomerDetails(String car_owner, String phone_no, String time) {
		super();
		this.car_owner = car_owner;
		this.phone_no = phone_no;
		this.time = time;
	}
	public String getCar_owner() {
		return car_owner;
	}
	public void setCar_owner(String car_owner) {
		this.car_owner = car_owner;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public void setSection(int section) {
		this.section = section;
	}
	public void setCompartment(int compartment) {
		this.compartment = compartment;
	}
	@Override
	public String toString() {
		return "CustomerDetails [car_owner=" + car_owner + ", phone_no=" + phone_no + ", time=" + time + ", floor="
				+ floor + ", section=" + section + ", compartment=" + compartment + "]";
	}
	
	
}
