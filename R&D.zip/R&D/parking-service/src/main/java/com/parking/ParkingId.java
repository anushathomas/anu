package com.parking;

public class ParkingId {

private int floor;
private int section;
private int compartment;
private int parkingid;
static int ParkingIdNo;
{
	setParkingid(++ ParkingIdNo);
}
public ParkingId(int floor, int section, int compartment) {
	super();
	this.floor = floor;
	this.section = section;
	this.compartment = compartment;
}
public int getParkingid() {
	return parkingid;
}
public void setParkingid(int parkingid) {
	this.parkingid = parkingid;
}
public int getFloor() {
	return floor;
}
public void setFloor(int floor) {
	this.floor = floor;
}
public int getSection() {
	return section;
}
public void setSection(int section) {
	this.section = section;
}
public int getCompartment() {
	return compartment;
}
public void setCompartment(int compartment) {
	this.compartment = compartment;
}
@Override
public String toString() {
	return "ParkingId [floor=" + floor + ", section=" + section + ", compartment=" + compartment + ", parkingid="
			+ parkingid + "]";
}



}
