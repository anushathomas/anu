package com.anu.date.test;

import com.anu.date.MyDate;

public class MyDateTestRecords {

	public MyDate startDate;
	public MyDate endDate;
	public long expectedResult;
	public MyDateTestRecords(MyDate startDate, MyDate endDate, long expectedResult) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.expectedResult = expectedResult;
	}
	
	
}
