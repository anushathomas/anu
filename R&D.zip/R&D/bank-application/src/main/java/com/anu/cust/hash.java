package com.anu.cust;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class hash {

	public static void main(String[] args) {
		HashMap<Integer,String> hashMap = new HashMap<Integer,String>();
		
		hashMap.put(1,"Anu");
		hashMap.put(2,"Nit");
		hashMap.put(3,"Sne");
		hashMap.put(4,"Ray");
		hashMap.put(5,"Ria");
		
		System.out.println(hashMap);
		
		//System.out.println(hashMap.get("Ray"));
		System.out.println(hashMap.get(5));
		
		for(Map.Entry M : hashMap.entrySet())
		{
			System.out.println(M.getKey()+":"+M.getValue());
		}
		
		System.out.println(hashMap.size());
		hashMap.clear();
		
		hashMap.put(1,"rahul");
		hashMap.put(2,"ajay");
		hashMap.put(3,"saddu");
		hashMap.put(4,"jason");
		hashMap.put(5,"henry");
		
		for(Map.Entry M : hashMap.entrySet())
		{
			System.out.println(M.getKey());
		}
		for(Map.Entry M : hashMap.entrySet())
		{
			System.out.println(M.getValue());
		}
	
		
		 Set<Entry<Integer, String>> set = hashMap.entrySet();
	        List<Entry<Integer, String>> list = new ArrayList<Entry<Integer, String>>(set);
	        Collections.sort( list, new Comparator<Map.Entry< Integer, String>>()
	        {
	            public int compare( Map.Entry< Integer, String> o1, Map.Entry<Integer, String> o2 )
	            {
	                return (o1.getValue()).compareTo( o2.getValue() );
	            }
	        } );
	        for(Entry<Integer, String> entry:list){
	            System.out.println(entry.getKey()+" ==== "+entry.getValue());
	        }
	        
	        System.out.println("============================");
	        Set<Entry<Integer, String>> set1 = hashMap.entrySet();
	        List<Entry<Integer, String>> list1 = new ArrayList<Entry<Integer, String>>(set);
	        Collections.sort( list, new Comparator<Map.Entry< Integer, String>>()
	        {
	            public int compare( Map.Entry< Integer, String> o1, Map.Entry<Integer, String> o2 )
	            {
	                return (o2.getKey()).compareTo( o1.getKey() );
	            }
	        } );
	        for(Entry<Integer, String> entry:list){
	            System.out.println(entry.getKey()+" ==== "+entry.getValue());
	        }
	    }
	}


