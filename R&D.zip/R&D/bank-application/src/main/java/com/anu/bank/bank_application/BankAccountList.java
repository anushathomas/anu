package com.anu.bank.bank_application;

public class BankAccountList {

	BankAccount accountarray[];
	int index=-1;
	
	public BankAccountList(int size)
	{   accountarray =new BankAccount[size];
	}
	
	public BankAccountList()
	{   accountarray =new BankAccount[100];
	}
	public void addaccount(BankAccount acc) {
	  accountarray[++index] = acc;
	}
	
	public BankAccount[] getAllBankAccount()
	{
		return accountarray;
	}
	
	public BankAccount getAccountbyId(int accountNo)
	{
		for(BankAccount acc: accountarray)
		{
			if(acc.getAccountNo()==accountNo)
				return acc;
		}
		throw new RuntimeException("account does not exist");
	}
   
	public BankAccount[] removeAccountById(int accountNo ,String accountHolderName)
	{
		for(int internalIndex=0;internalIndex<=index;internalIndex++)
		{
			if(accountarray[internalIndex].getAccountNo()==accountNo)
			{accountarray[internalIndex].setAccountHolderName(accountHolderName);
			return accountarray;
			}
		}
		throw new RuntimeException("Account does not exist");
	}
}
	
	
