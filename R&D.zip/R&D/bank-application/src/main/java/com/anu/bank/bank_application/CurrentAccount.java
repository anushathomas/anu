package com.anu.bank.bank_application;

public class CurrentAccount extends BankAccount {

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		System.out.println("Current account withraw method");
		
		
	}

	public void getInsurancename() {
		// TODO Auto-generated method stub
		
	}

	public void getInsuranceperiod() {
		// TODO Auto-generated method stub
		
	}

}
