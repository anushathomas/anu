package com.anu.bank.bank_application;

public class SavingsAccountv2 extends SavingsAccount implements InsuranceProvider{

	public  void getInsurancename()
	{

}
	public void getInsuranceperiod() {
		// TODO Auto-generated method stub
		
	}
	
	
}
