package com.anu.bank.bank_application;

public interface InsuranceProvider {
abstract  void getInsurancename();
abstract void  getInsuranceperiod();
}
