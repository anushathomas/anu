package com.anu.bank.bank_application;

public class CurrentAccountv2 extends CurrentAccount implements InsuranceProvider {

	public  void getInsurancename()
	{

}
	public void getInsuranceperiod() {
		// TODO Auto-generated method stub
		
	}
}
