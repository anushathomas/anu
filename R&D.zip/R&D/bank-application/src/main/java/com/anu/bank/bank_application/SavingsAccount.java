package com.anu.bank.bank_application;

public class SavingsAccount extends BankAccount {

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		
	}

	
		 
	}
	
