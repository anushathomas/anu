package com.anu.cust;


import com.anu.bank.bank_application.BankAccount;
import com.anu.bank.bank_application.BankAccountList;


public class Customer {
	
	public static void main(String [] args)
	{    
		
		
	   
		//BankAccount acc1=null;
		 //acc1 = new SavingsAccount();
		 //acc1.withdraw(5000);
		//System.out.println("Bank account 1"+ acc1);
		BankAccount acc =new BankAccount("anu",12345);
		BankAccount acc2 =new BankAccount("sne",12345);
		BankAccountList list= new BankAccountList();
		list.addaccount(acc);
		list.addaccount(acc2);
		
		
		
		System.out.println(list);
		list.getAccountbyId(1);
		
		System.out.println(list);
	}
}