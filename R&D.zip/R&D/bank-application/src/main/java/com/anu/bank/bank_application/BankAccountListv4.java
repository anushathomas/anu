package com.anu.bank.bank_application;

import java.util.Collections;
import java.util.Iterator;
import java.util.HashSet;

public class BankAccountListv4 {
	HashSet<BankAccount> list1 = new HashSet<BankAccount>();
	BankAccount acc =new BankAccount("anu",12345);
	BankAccount acc2 =new BankAccount("sne",12345);
	
	public void addCustomer(BankAccount acc)
	{
	list1.add(acc);
	
	}
	public HashSet<BankAccount> getAllBankAccount()
	{
		return list1;
	}
	public void delCustomer(int accNo)
	{
		
	
	System.out.println("Enter Account Number to be Delete");
	
	Iterator<BankAccount> it = list1.iterator(); 
	while(it.hasNext()) 
	{


	if(accNo == acc.getAccountNo()) 
	list1.remove(acc); 
    }
	}
	public void updateCustomerById(String accountHolderName, int accNo)
	{
		
	
		for(BankAccount acc: list1)
		{
			if(accNo == acc.getAccountNo()) 
			{
				acc.setAccountHolderName("nit");
			}
		}
	}
	public HashSet<BankAccount> sortByAccountName()
	{
		Collections.sort(list1,(BankAccount acc,BankAccount acc1)-> acc.getAccountHolderName().compareTo(acc1.getAccountHolderName()));
		return list1;
	}
	
	

}
