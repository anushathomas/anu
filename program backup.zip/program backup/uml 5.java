import java.util.Scanner;
public class GradesAverage
{
	public static void main(String[] args)
	{
		int sum=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of students:");
		int x= sc.nextInt();
		int[] grades = new int[x];
		for(i=0;i<x;i++)
		{
			grades[i]=sc.nextInt();
			system.out.println("Enter the grade for student"+i+grades[i]);
			
			if (grades[i]<0&&grades[i]>100)
			{
				
			System.out.println("Invalid grade,try again...");
		    }
			else
			sum = sum + grades[i];
			
		}
 double average=sum/x;

System.out.println("The average is:" +average);
}
} 
		
		
		
		