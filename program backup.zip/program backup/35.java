   public class MyClass {
    public static void main(String args[]) {
       double mp,sp,amt,dis=35;
       mp=10000;
       sp=100-dis;
amt=(sp*mp)/100;
       System.out.println( "new amt is" + amt);
       

    }
      }     
