package techm.collections.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Allows null elements
		// allows duplicate elements
                                        //preserve insertion order
                                        /
		ArrayList<String> a1 = new ArrayList<String>();

		a1.add("Apple");
		a1.add("Banana");
		a1.add("");
		a1.add("Grapes");
		a1.add("Apple");

		System.out.println("Elements in ArrayList are");
		System.out.println(a1);

		// Retrieve the elements
		System.out.println(a1.get(1));

		// add element at specific index
		a1.add(3, "Mango");
		System.out.println(a1);

		System.out.println(a1.indexOf("Banana"));// position of Object
		System.out.println(a1.size());

		// Read elements in ArrayList

		System.out.println("Read elements using iterator");

		Iterator<String> itr = a1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

		// Copy the content into another ArrayList
		List<String> a2 = new ArrayList<String>();
		a2.addAll(a1);
		
	}

	
}
