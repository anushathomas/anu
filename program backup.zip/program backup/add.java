class Simple{  
public static void main(String[] args){  
int a;  
int b;
Scanner s = new Scanner(System.in);
System.out.println("Enter the a and b");
  a = in.nextInt();
      b = in.nextInt();
 
int c=a+b;  
System.out.println(c);  
}}  
