import java.util.*;
public class Account
{
private String id;
private String name;
private int balance=0;

public Account(String id,String name)
{
this.id=id;
this.name=name;
}
public Account(String id,String name, int balance)
{
this.id=id;
this.name=name;
this.balance=balance;
}
public String getId()
{
return this.id;
}
public String getName()
 return this.name;
}
public int getBalance()
{
return this.balance;
}
public int credit(int amount)
{
this.balance=this.balance+amount;
return this.balance;
}
public int debit(int amount)
{
if(amount<=this.balance)
this.balance=this.balance-amount;
else
System.out.println("Amount exceeded balance");
return this.balance;
}
public int transferTo(Account another, int amount)
{
if(amount<=this.balance)
{
this.debit(amount);
another.credit(amount);
}
else
System.out.pintln("Amount exceeded balance");
return this.balance;
}
public String toString()
{
return("Account[id=+this.getId()+",name="+this.getName()+" balance="+this.getBalance()+"]");
}
public static void main( String[] args)
{
Scanner in = new Scanner(System.in);
String id2,name2;
int balance;
System.out.println("Enter account 1 details: ");
System.out.pintln("Enter ID: ");
id2=in.nextInt();
System.out.println("Enter name: ");
name2=in.next();
System.out.println("Enter balance: ");
balance2=in.nextInt();
Account ob=new Account(id2,name2,balance2);

System.out.println("Enter account 2 details: ");
System.out.pintln("Enter ID: ");
id2=in.nextInt();
System.out.println("Enter name: ");
name2=in.next();
System.out.println("Enter balance: ");
balance2=in.nextInt();
Account ob=new Account(id2,name2,balance2);

System.out.println("Enter the amount to transfer: ");
int amount=in.nextInt();
ob.transferTo(ob2,amount);
String amn1=ob.toString();
System.out.println(amn1);

String amn2=ob2.toString();
System.out.println(amn2);






}
}