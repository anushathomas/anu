public class Person {
   // private instance variables
   private String name, address;
   
   // Constructor
   public Person(String name, String address) {
      this.name = name;
      this.address = address;
   }
   
   // Getters and Setters
   public String getName() {
      return name;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   
   // Describle itself
   public String toString() {
      return "Person[name="+getName()+"address="+getAddress+"]";
	  }
	  }
	  public class Student extends Person {
	  private String program;
	  private int year;
	  private double fee;
	  
	  public Student(String name,String address,String program, int year, double fee)
	  {
	  this.name=name;
	  this.program=program;
	  this.year=year;
	  this.fee=fee;
	  }
	  public  String getProgram()
	  {
		  return program;
	  }
	  public void setProgram(String program )
	  {
		  this.program=program;
	  }
	  public int getYear()
	  {
		  return year;
	  }	  
	  public void setYear(int year)
	  {
		  this.year=year;
	  }
	  public double getFee()
	  {
		  return fee;
	  }
	  public void setFee(double fee)
	  {
		  this.fee=fee;
	  }
	  public String toString()
	  {
		  return ("Student[Person[name="+name+"address="+address+"],program="+getProgram()+",year="+getYear+",fee="+getFee+"]");
	  }
	  }
	  public class Staff extends Persons()
	  {
		  private String school;
		  private double pay;
		  
		  public Staff( String name,String address,String school,double pay)
		  {
			  this.name=name;
			  this.address=address;
			  this.school=school;
			  this.pay=pay;
		  }
		  public String getSchool()
		  {
			  return school;
		  }
		  public void setSchool(String school)
		  
		  {
			this.school=school;  
			  
		  }
		  public double getPay()
		  {
			  return pay;
		  }
		  public void setPay(double pay)
		  {
			  this.pay=pay;
		  }
		  public String toString()
{
return ("Staff[Person[name="+name+"address="+address+"],school"+getSchool+",pay="+getPay"]");
		  
	  }
   }

class person1
{
public static void main(String [] args)
{
person ob= new person("Anusha","Bangalore");
System.out.println("The name is:"+getName);
System.out.println("The address is:"+getAddress);
System.out.println(toString);


student ob1=new student("Anusha","Bangalore","Engineering",2001,1000.00);
System.out.println("The name is:"+getName);
System.out.println("The address is:"+getAddress);
System.out.println("The program is:"+getProgram);
System.out.println("The year is:"+getYear);
System.out.println("The fee is:"+getFee);
System.out.println(toString);

staff ob2= new staff("Sahana","Bangalore","BCGS",10277.99);
System.out.println("The name is:"+getName);
System.out.println("The address is:"+getAddress);
System.out.println("The school is:"+getSchool);
System.out.println("The pay is:"+getPay);
System.out.println(toString);

}
}

