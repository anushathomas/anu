package monday;
import java.util.*;

class Movie_Details implements Comparable<Movie_Details>{
	String mov_Name;
	String lead_actor;
	String lead_actress;
	String genre;
	public static int choice=8;
	public Movie_Details(String name,String actor,String actress,String genre)
	{
		this.mov_Name=name;
		this.lead_actor=actor;
		this.lead_actress=actress;
		this.genre=genre;
	}
	public String getMov_Name() {
		return mov_Name;
	}
	public void setMov_Name(String mov_Name) {
		this.mov_Name = mov_Name;
	}
	public String getLead_actor() {
		return lead_actor;
	}
	public void setLead_actor(String lead_actor) {
		this.lead_actor = lead_actor;
	}
	public String getLead_actress() {
		return lead_actress;
	}
	public void setLead_actress(String lead_actress) {
		this.lead_actress = lead_actress;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public void display(){
		System.out.println("Movie Details :\nMovie Name : "+this.getMov_Name()+"\nLead Actor : "+this.getLead_actor()+"\nLead Actress : "+this.getLead_actress()+"\ngenre :"+this.getGenre());
	}
	
	public int compareTo(Movie_Details m){
		if(choice==1)
			return this.getMov_Name().compareTo(m.getMov_Name());
		else if(choice==2)
			return getLead_actor().compareTo(m.getLead_actor());
		else if(choice==3)
			return getLead_actress().compareTo(m.getLead_actress());
		else 
			return getGenre().compareTo(m.getGenre());
	}
}



public class Movie_DetailsList {


	public static Set<Movie_Details> set= new TreeSet<Movie_Details>();
	
	public void add_movie(String mov_Name, String lead_actor, String lead_actress, String genre){
		set.add(new Movie_Details(mov_Name, lead_actor, lead_actress, genre));
	}
	
	public void remove(String mov_Name)
	{
		for(Movie_Details m: set)
		{
			if(m.getMov_Name().equals(mov_Name))
				 set.remove(((List<Movie_Details>)set).indexOf(m));
		}
	}
   
	public void remove_AllMovies()
	{
		set.removeAll(set);
	}
	
	public void find_movie_By_mov_Name(String mname){
		for(Movie_Details m:set){
			if(m.getMov_Name().equals(mname))
				m.display();
		}
	}
	
	public void find_movie_By_Genre(String gen){
		for(Movie_Details m:set){
			if(m.getGenre().equals(gen))
				m.display();
		}
	}
	
	public void takeChoice(int c){
		Movie_Details.choice = c;
	}
	
	public void show(){
		for(Movie_Details m:set){
			m.display();
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		
		Movie_DetailsList mdl =new Movie_DetailsList();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter choice to sort list:\n1.Movie name\n2.Lead Actor\n3.Lead Actress\n4.Genre");
		int ch = sc.nextInt();
		if(ch<1 || ch>4){
			System.out.println("Invalid input");
			System.exit(0);
		}
		mdl.takeChoice(ch);
		ch=1;
		String mov_Name,lead_actor,lead_actress,genre;
		boolean t=true;
		while(t){
			switch(ch){
			case 1 : System.out.println("Enter details of movie:  ");
		mov_Name=sc.next();
			lead_actor=sc.next();
			lead_actress=sc.next();
			genre=sc.next();
			mdl.add_movie(mov_Name, lead_actor, lead_actress, genre);
			System.out.println(" Add another movie? (Y/N)");
			mov_Name=sc.next();
			if(mov_Name.equalsIgnoreCase("Y")==true)
				t=true;
			else
				t=false;
			break;
			
		default : t =false;	
			}
		}
		System.out.println("Movie Details");
		mdl.show();
	}

}
