import java.util.Scanner;
public class KeyboardScanner
{
public static void main (String args[])
{ 
Scanner in =new Scanner(System.in);
int x=in.nextInt();
System.out.println("Enter a integer" +x);
double y=in.nextDouble();
System.out.println("Enter a floating point no" +y);
String str=in.next();
System.out.println("Enter your name" +str);
double z=(x+y);
System.out.println("Hi!" +str+", the sum of"+x+" and "+y+"is" +z);
}
}


