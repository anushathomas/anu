package com.cloud.controller;



import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.model.Employee;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@RestController
public class TestController {
	
	@RequestMapping(value="/employee", method=RequestMethod.GET)
	@HystrixCommand(fallbackMethod="getDataFallback")
	public Employee firstPage()
	{
		Employee emp=new Employee("1","Manager","Loki",5000);
		if(emp.getEmpId().equals("1"))
		{
			throw new RuntimeException();
		}
		return emp;
	}
	public Employee getDataFallback()
	{
		Employee emp1=new Employee("fallback-1","fallback-Manager","fallback-Loki",5000);
		return emp1;
	}

}
